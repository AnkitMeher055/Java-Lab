class Tild{
public static void main(String arg[]){

System.out.println(~4);
System.out.println(-4);

}
}