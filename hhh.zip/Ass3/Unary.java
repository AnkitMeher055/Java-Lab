class Unary{
public static void main(String arg[]){
int a = 1;

a = (++a)+(a++)-(a--)+(--a);

System.out.println(a);
}
}