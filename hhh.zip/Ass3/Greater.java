class Greater{
public static void main(String arg[])
{
int a = Integer.parseInt(arg[0]);
int b = Integer.parseInt(arg[1]);
int ans =0;
ans= (a>b)?a:b;
System.out.println(ans + " is greater");
}
}
