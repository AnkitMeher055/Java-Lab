class TempretureConversion{
public static void main(String arg[])
{

float tempreture = 67;
System.out.println("Tempreture in Fehrenhite "+tempreture);
System.out.println("Converting  in celcius");
float celcius = 5/9f*(tempreture - 32);
System.out.println("Tempreture in celcius " + celcius);
}
}
