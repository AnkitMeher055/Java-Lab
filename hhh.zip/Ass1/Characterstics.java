public class Characterstics
{
public static void main(String ar[])
{
System.out.println("Java characterstics:");
System.out.println("Class");
System.out.println("Polymorphism");
System.out.println("Inheritance");
System.out.println("Abstraction");
System.out.println("Encapsulation");
}
}