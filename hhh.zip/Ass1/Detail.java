public class Detail
{
public static void main(String ar[])
{
String name = "Ankit Meher";
System.out.println(name);
}
}