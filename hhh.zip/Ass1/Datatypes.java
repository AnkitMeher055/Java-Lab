public class Datatypes
{
public static void main(String ar[])
{
int a = 23;
Float b = 23.34f;
double c = 34.34;
String name = "Ankit Meher";
char ch = 'a';
boolean bool = true;
long large = 232423232343L;

System.out.println("int value= "+a);
System.out.println("FLoat value = "+b);
System.out.println("String value = "+name);
System.out.println("Character value = "+ch);
System.out.println("Boolean value = "+bool);
System.out.println("Long value = "+large);

}
}