public class Greeting
{
public static void main(String ar[])
{
String name ="Ankit Meher";
System.out.println("Welcome: " + name);
}
}