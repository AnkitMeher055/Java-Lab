import java.util.Scanner;
class Operation{
public static void main(String ar[])
{
    Scanner sc = new Scanner(System.in);
    int a = sc.nextInt();
    int b = sc.nextint();

    System.out.println("result  = ",a+b);
    System.out.println("result  = ",a*b);
    System.out.println("result  = ",a/b);
    System.out.println("result  = ",a%b);



}
}
