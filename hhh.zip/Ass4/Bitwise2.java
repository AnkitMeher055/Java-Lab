public class Bitwise2{
public static void main(String ar[])
{
int num1 = 20;
int num2 = 12;
//int result = num1 & num2;
//int rsult = num1 | num2;
//int result = num1 ^ num2;
int result = ~num1;
//int result = -num1;


System.out.println(num1);
System.out.println(num2);
System.out.println(result);


}
}