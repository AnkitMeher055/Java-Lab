public class Bitwise{
public static void main(String ar[])
{
int v = 10;
int n = 1;

int leftResult = v<<n;
int rightResult = v>>n;
System.out.println(leftResult);
System.out.println(rightResult);


System.out.println(v>>>n);


}
}